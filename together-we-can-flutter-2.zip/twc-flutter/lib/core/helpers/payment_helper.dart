import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../app/constants.dart';
import '../services/api_service.dart';

/// Ouvre le lien de recharge Chariow, avec un rappel clair sur ce qui va
/// se passer (paiement hors de l'app, crédit du solde après confirmation).
Future<void> openRechargeLink({String? userEmail}) async {
  final confirmed = await Get.dialog<bool>(
    AlertDialog(
      title: const Text('Recharger mon solde'),
      content: const Text(
        'Vous allez être redirigé vers la page de paiement sécurisée. '
        'Choisissez le montant que vous souhaitez recharger et payez avec '
        'Mobile Money ou carte bancaire.\n\n'
        'Votre solde sera crédité automatiquement une fois le paiement confirmé '
        '(quelques minutes).',
      ),
      actions: [
        TextButton(onPressed: () => Get.back(result: false), child: const Text('Annuler')),
        ElevatedButton(
          onPressed: () => Get.back(result: true),
          style: ElevatedButton.styleFrom(backgroundColor: AppConstants.primaryColor),
          child: const Text('Continuer', style: TextStyle(color: Colors.white)),
        ),
      ],
    ),
  );

  if (confirmed != true) return;

  var url = AppConstants.rechargeUrl;
  if (userEmail != null && userEmail.isNotEmpty) {
    url = '$url?email=${Uri.encodeComponent(userEmail)}';
  }

  final uri = Uri.parse(url);
  if (await canLaunchUrl(uri)) {
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  } else {
    Get.snackbar('Erreur', 'Impossible d\'ouvrir la page de paiement.');
  }
}
