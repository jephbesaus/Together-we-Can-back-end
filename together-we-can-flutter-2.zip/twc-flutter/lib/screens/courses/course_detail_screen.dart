import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../app/constants.dart';
import '../../core/services/api_service.dart';

class CourseDetailScreen extends StatefulWidget {
  final String courseId;

  const CourseDetailScreen({super.key, required this.courseId});

  @override
  State<CourseDetailScreen> createState() => _CourseDetailScreenState();
}

class _CourseDetailScreenState extends State<CourseDetailScreen> {
  final ApiService _api = Get.find<ApiService>();
  Map<String, dynamic>? _course;
  bool _isLoading = true;
  final Set<int> _completingLessons = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _isLoading = true);
    try {
      final response = await _api.get('/courses/${widget.courseId}');
      if (response['success']) {
        setState(() => _course = response['data']['course']);
      }
    } catch (e) {
      print('Error loading course: $e');
    }
    setState(() => _isLoading = false);
  }

  Future<void> _markLessonComplete(int lessonId, int durationSeconds) async {
    setState(() => _completingLessons.add(lessonId));
    try {
      final response = await _api.post(
        '/courses/${widget.courseId}/lessons/$lessonId/progress',
        data: {'position': durationSeconds, 'duration': durationSeconds},
      );
      if (response['success']) {
        Get.snackbar('Bravo !', 'Leçon marquée comme terminée.');
        _load();
      }
    } catch (e) {
      Get.snackbar('Erreur', 'Erreur réseau.');
    }
    setState(() => _completingLessons.remove(lessonId));
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    if (_isLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    if (_course == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Formation')),
        body: const Center(child: Text('Formation introuvable')),
      );
    }

    final sections = List<Map<String, dynamic>>.from(_course!['sections'] ?? []);
    final isEnrolled = _course!['is_enrolled'] == true;
    final progress = _course!['progress'] ?? 0;

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            pinned: true,
            expandedHeight: 180,
            backgroundColor: theme.scaffoldBackgroundColor,
            flexibleSpace: FlexibleSpaceBar(
              background: _course!['cover_image'] != null
                  ? CachedNetworkImage(imageUrl: _course!['cover_image'], fit: BoxFit.cover)
                  : Container(color: AppConstants.primaryColor),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(_course!['title'] ?? '', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(_course!['description'] ?? '', style: TextStyle(color: Colors.grey[600])),
                  const SizedBox(height: 16),
                  if (isEnrolled) ...[
                    LinearProgressIndicator(
                      value: (progress as num) / 100,
                      backgroundColor: Colors.grey[300],
                      color: AppConstants.primaryColor,
                    ),
                    const SizedBox(height: 4),
                    Text('$progress% terminé', style: const TextStyle(fontSize: 12)),
                  ] else
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.orange.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Text('Inscrivez-vous depuis le catalogue pour accéder aux leçons.'),
                    ),
                  const SizedBox(height: 20),
                  const Text('Contenu de la formation', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
          ),
          SliverList(
            delegate: SliverChildBuilderDelegate(
              (context, sectionIndex) {
                final section = sections[sectionIndex];
                final lessons = List<Map<String, dynamic>>.from(section['lessons'] ?? []);
                return ExpansionTile(
                  title: Text(section['title'] ?? '', style: const TextStyle(fontWeight: FontWeight.w600)),
                  children: lessons.map((lesson) {
                    final isCompleted = lesson['is_completed'] == true;
                    final lessonId = lesson['id'];
                    final isCompleting = _completingLessons.contains(lessonId);
                    return ListTile(
                      leading: Icon(
                        isCompleted ? Icons.check_circle : Icons.play_circle_outline,
                        color: isCompleted ? Colors.green : AppConstants.primaryColor,
                      ),
                      title: Text(lesson['title'] ?? ''),
                      subtitle: Text(lesson['formatted_duration'] ?? ''),
                      trailing: !isEnrolled
                          ? const Icon(Icons.lock_outline, size: 18)
                          : isCompleting
                              ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                              : (isCompleted
                                  ? null
                                  : IconButton(
                                      icon: const Icon(Icons.check),
                                      tooltip: 'Marquer comme terminée',
                                      onPressed: () => _markLessonComplete(
                                        lessonId,
                                        int.tryParse('${lesson['video_duration'] ?? 60}') ?? 60,
                                      ),
                                    )),
                    );
                  }).toList(),
                );
              },
              childCount: sections.length,
            ),
          ),
        ],
      ),
    );
  }
}
