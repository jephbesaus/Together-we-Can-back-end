<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\FusionPayService;
use App\Services\ChariowService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class WebhookController extends Controller
{
    protected $fusionPay;
    protected $chariow;

    public function __construct(FusionPayService $fusionPay, ChariowService $chariow)
    {
        $this->fusionPay = $fusionPay;
        $this->chariow = $chariow;
    }

    public function fusionPay(Request $request)
    {
        if (!$this->fusionPay->verifySignature($request)) {
            Log::warning('Webhook FusionPay rejeté : signature invalide.', ['ip' => $request->ip()]);
            return response()->json(['status' => 'error', 'message' => 'Invalid signature'], 403);
        }

        $result = $this->fusionPay->handleWebhook($request->all());

        return response()->json($result);
    }

    public function chariow(Request $request)
    {
        $result = $this->chariow->handleWebhook($request->all());

        return response()->json($result);
    }
}
